# آموزش نصبِ قدم‌به‌قدمِ اپِ VpnForge روی گوشی (از طریق گیت‌هاب)

این راهنما به‌صورتِ کامل و درست، مراحلِ نصبِ اپِ **VpnForge** روی گوشی أندرویدی را از طریق **گیت‌هاب** توضیح می‌دهد. هم نام اپ و هم **تمامِ فایل‌های پروژه** در این راهنما بیان شده‌اند.

---

## نام اپ

**VpnForge** — اپِ VPNِ اندرویدی با سرورهای داخلی (سرورهای کلادفلرِ ساخته‌شده).

---

## تمامِ فایل‌های پروژه

```
VpnForge/
│
├── settings.gradle.kts                 # configِ اصلیِ Gradle
├── build.gradle.kts                    # dependencyها و pluginها (root)
├── gradle.properties                   # تنظیماتِ Gradle
├── gradle/
│   └── gradle-wrapper.properties      # configِ wrapperِ Gradle
│
├── app/
│   ├── build.gradle.kts                # configِ اپ (APK)
│   └── src/main/
│       ├── AndroidManifest.xml         # پرمیسین‌ها + declarationِ سرویس VPN
│       ├── assets/
│       │   └── servers.json            # ← سرورهای داخلیِ اپ (همین‌جا سرورها را تنظیم می‌کنی)
│       ├── kotlin/com/vlessvpn/
│       │   ├── MainActivity.kt         # صفحه اصلی: لیست سرور + اتصال/قطع
│       │   ├── VlessVpnService.kt      # سرویس VPN (VpnService)
│       │   ├── VpnTcpStack.kt          # stackِ TCP/IP + تونل VLESS
│       │   ├── VlessTunnel.kt          # client VLESS-over-WebSocket
│       │   └── ServerConfig.kt         # مدل سرور + بارگذاری از assets
│       └── res/
│           ├── layout/
│           │   └── activity_main.xml   # layoutِ صفحه اصلی
│           └── values/
│               ├── strings.xml         # نام اپ (VpnForge) و متن‌ها
│               ├── colors.xml          # رنگ‌ها
│               └── themes.xml          # تم
│
├── .github/
│   └── workflows/
│       └── build-apk.yml               # خودِ buildِ APK روی گیت‌هاب (GitHub Actions)
│
├── home.html                            # صفحه اصلیِ اپ (HTMLِ standalone)
├── vpn_mobile_layout.png               # تصویرِ چیدمان موبایل
├── vpn_home_preview.png                # تصویرِ صفحه اصلی
├── vpnforge_logo.png                   # لوگوی اپ
├── README.md                           # راهنمای پروژه
└── INSTALL.md                          # ← همین آموزشِ نصب
```

> فایلِ **`app/src/main/assets/servers.json`** مهم‌ترین فایلِ تنظیمِ سرور است — بعد از نصب، سرورهای کلادفلرِ خودت را در اینجا می‌نویسی.

---

## قدم ۱ — پیش‌نیازها

1. یک **account گیت‌هاب**.
2. روی ماشینِ خود (Windows/macOS/Linux):
   - **Android Studio** نصب شده باشد (برای ساختِ APK).
   - یا فقط **JDK 17** + **Android SDK** (اگر از command line می‌خواهی).
3. یک **تلفن أندرویدی** با أندرویدِ 7.0 (minSdk 24) به‌after.

---

## قدم ۲ — پروژه را به گیت‌هاب پوشender کن

1. گیت‌هاب را باز کن → **New repository**.
   - **Name**: `VpnForge`
   - **Public** یا **Private** (برای استفاده شخصی، Private هم می‌تواند).
2. مسیرِ پروژه (`VpnForge/`) را روی ماشینِ خود باز کن.
3.أول initial commit کن:

   ```bash
   cd VpnForge
   git init
   git add .
   git commit -m "initial VpnForge project"
   ```

4. remoteِ گیت‌هاب را اضافه کن و push کن:

   ```bash
   git remote add origin https://github.com/<username>/VpnForge.git
   git branch -M main
   git push -u origin main
   ```

> ✅ اکنون تمامِ فایل‌های پروژه روی گیت‌هاب هستند.

---

## قدم ۳ — ساختِ APK (دو راه)

### راه A — محلی با Android Studio (ساده‌ترین)

1. **Android Studio** را باز کن → **Open** → مسیرِ `VpnForge/` را انتخاب کن.
2.برای نخستین بار که باز می‌شود، Android Studio dependencies را Lad و sync می‌کند (چند دقیقه).
3. بعد از کاملِ sync: منو → **Build → Build Bundle(s)/APK(s) → Build APK(s)**.
4. منتظر بمان تا **"Build: Completed"** بیاید.
5. فایلِ APK اینجاست:

   ```
   VpnForge/app/build/outputs/apk/debug/app-debug.apk
   ```

   > این **debug APK** است — برای نصبِ شخصی روی گوشی کاملاً کافی است.

### راه B — خودکار با GitHub Actions

همون workflowِ `.github/workflows/build-apk.yml`، بعد از هر push، خودِ APK را build می‌کند:

1. بعد از push (قدم ۲)، گیت‌هاب → پروژه → **Actions**.
2. کارِ **Build APK** را باز کن — باید کامل شود.
3. در مشعِ **Upload APK artifact**، روی `app-release` کلیک کن → **Download artifact**.
4. فایلِ `.apk` را بیرون بیاور.

> ✅ با هر دو راه، یک فایلِ `.apk` داری.

---

## قدم ۴ — آپلود APK به گیت‌هاب و ساختِ Release

1. گیت‌هاب → پروژه → **Releases** → **Draft a new release**.
2. **Tag**: `v1.0` انتخاب کن (يا New tag بساز).
3. **Release title**: `VpnForge v1.0`.
4. در بخشِ **Attach binaries**:
   - **Choose an existing asset** → فایلِ `.apk`ی که ساختی را انتخاب کن (يا Drag و drop کن).
5. **Publish release** کن.

> ✅ اکنون لینکِ دانلودِ مستقیمِ APK برایت شده:
> `https://github.com/<username>/VpnForge/releases/download/v1.0/app-debug.apk`
> (نام و tagِ خودت را جایگزین کن.)

---

## قدم ۵ — دانلود و نصب روی گوشی

1. روی گوشی، لینکِ Release را در مرورگر باز کن:
   - `https://github.com/<username>/VpnForge/releases`
   - یا لینکِ مستقیمِ دانلودِ APK (از قدم ۴).
2. روی **Download** بزن — فایلِ `.apk` دانلود می‌شود.
3. اگر پیامِ **«ثبت‌نام‌کنندگانِ مورد اعتمادِ این منبع، این packages را Unknown می‌دانند»** آمد:
   - روی **Settings** / **Install anyway** بزن.
   - اجازهِ **«نصبِ فایلی از این منبع»** را بده.
4. روی **Install** بزن تا نصب تمام شود.

> 💡 اگر نصب نشد: از **تنظیمات → امنیت**، مجوزِ **«نصب از منابعِ ناشناخته»** را برای browserِ خود فعال کن.

---

## قدم ۶ — تنظیمِ سرورها و اتصال

1. فایلِ **`app/src/main/assets/servers.json`** را باز کن و سرورهای کلادفلرِ خودت را بنویس:

   ```json
   [
     {
       "name": "سرور ۱ — کلادفلر",
       "server": "vpn.example.com",
       "port": 443,
       "uuid": "يزينة UUIDِ سرور کلادفلر",
       "path": "/k9x2-vless-tunnel-7f3a",
       "tls": true,
       "host": "vpn.example.com"
     }
   ]
   ```

   > `uuid`، `path` و `server` را با قدرهای **سرور کلادفلرِ خودت** (از پروژه `cf-vless-vpn`) جایگزین کن.
   > می‌توانی چندین سرور بیفزایی (هر کدام یک entry).

2. دوباره **Build APK** کن (راه A یا B) و APKِ جدیدی نصب کن.
3. در اپِ **VpnForge**، سرور را انتخاب کن → دکمه‌ی **اتصال (power)** → اجازهِ VPN را بده.

---

## خلاصهِ سریع

```
پوشیدن پروژه به گیت‌هاب  (git push)
        ↓
ساختِ APK  (Android Studio / GitHub Actions)
        ↓
آپلود APK → Release در گیت‌هاب
        ↓
دانلود APK روی گوشی → نصب (اجازهِ منابعِ ناشناخته)
        ↓
تنظیمِ سرورها در servers.json → build → نصب → اتصال
```

---

## نکات مهم

- برای **نصبِ شخصی**، **debug APK** کافی است. برای **release APKِ signed** (ارائه عمومی)، باید در `app/build.gradle.kts` یک `signingConfigs` به `buildTypes.release` اضافه کن و private key را مدیریت کن.
- **GitHub Actions**: اگر build شکست خورد، Java 17 و Android SDKِ setup را چک کن؛مسیرِ output: `app/build/outputs/apk/release/*.apk`.
- **سرورهای مختص فرد**: هر UUIDِ مختص فرد را هم در لیستِ `UUIDS`ِ Workerِ کلادفلر و هم در `servers.json`ِ اپ قرار بده.
- **تصویرِ چیدمان**: `vpn_mobile_layout.png` نشان‌دهنده‌ی صفحه اصلیِ نهاییِ اپ است.
