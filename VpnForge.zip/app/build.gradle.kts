plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.vlessvpn"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.vlessvpn"
        minSdk = 24
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
    }

    // یونویرسال: یک APKِ یک‌دست برای تمامِ گوشی‌ها
    // (بدون splits/abiFilters — Gradle یک APKِ واحد برای تمامِ ABIها می‌سازد)

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

dependencies {
    implementation("androidx.core:core-ktx:1.13.1")
    implementation("androidx.appcompat:appcompat:1.7.0")
    implementation("com.google.android.material:material:1.12.0")
    // client WebSocket برای VLESS-over-WebSocket
    implementation("com.squareup.okhttp3:okhttp:4.12.0")
}
