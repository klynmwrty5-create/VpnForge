package com.vlessvpn

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import java.io.ByteArrayOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

/**
 * یک ارتباط VLESS-over-WebSocket به سرور (Worker کلادفلر).
 *
 * نیزه کار:
 *  1. با wss://domain:port/path یک WebSocket باز می‌کند.
 *  2. سر شری VLESS (version + UUID + addon + command TCP + port + آدرس) می‌فرستد.
 *  3. سر شری پاسخ سرور (۲ بایت ۰x00 ۰x00) را می‌خواند و داده‌های بعدی را از طریق
 *     [onData] ارائه می‌دهد.
 *  4. داده‌های TCP از [send] می‌روند تا سرور.
 */
class VlessTunnel(
    private val config: ServerConfig,
    /** آدرس مقصد به صورت IP یا domain (مثل ۹۳.۱۸۴.۲۱۶.۳۴ یا example.com) */
    private val target: String,
    private val port: Int,
    private val onData: (ByteArray) -> Unit,
    private val onClose: () -> Unit
) {
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    private var ws: WebSocket? = null
    private val headerLatch = CountDownLatch(1)
    private val pendingHeader = ByteArrayOutputStream()
    private var headerConsumed = false
    private var closed = false

    /** اتصال به سرور و انتظار سر شری پاسخ. با موفقیت true برمی‌گرداند. */
    fun connect(): Boolean {
        val header = buildVlessHeader(target, port)
        val request = Request.Builder().url(config.wsUrl()).build()

        val socket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: okhttp3.Response) {
                ws = webSocket
                webSocket.send(WebSocket.BINARY, ByteString.of(header))
            }

            override fun onMessage(webSocket: WebSocket, text: String) {
                /* متن (text) برای VLESS کاربردی ندارد */
            }

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                val data = bytes.toByteArray()
                if (!headerConsumed) {
                    // جمع‌آوری تا سر شری پاسخ کامل (۲ بایت) حاضر شود
                    synchronized(pendingHeader) {
                        pendingHeader.write(data)
                        if (pendingHeader.size() >= 2) {
                            headerConsumed = true
                            val all = pendingHeader.toByteArray()
                            pendingHeader.reset()
                            headerLatch.countDown()
                            // هر داده‌ی اضافه پشت سر سر شری پاسخ
                            if (all.size > 2) {
                                val rest = all.copyOfRange(2, all.size)
                                onData(rest)
                            }
                        }
                    }
                } else {
                    onData(data)
                }
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                webSocket.close(1000, null)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (!closed) {
                    closed = true
                    onClose()
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: okhttp3.Response?) {
                if (!closed) {
                    closed = true
                    onClose()
                }
            }
        })

        val ok = headerLatch.await(15, TimeUnit.SECONDS)
        if (!ok) {
            socket.cancel()
            return false
        }
        return true
    }

    /** sending داده‌های TCP (payload) به سرور */
    fun send(data: ByteArray) {
        ws?.send(WebSocket.BINARY, ByteString.of(data))
    }

    /** بستنِ تونل */
    fun close() {
        try {
            if (!closed) {
                closed = true
                ws?.close(1000, "client closing")
            }
        } catch (_: Exception) {
        }
    }

    /** ساخت سر شری درخواست VLESS */
    private fun buildVlessHeader(ip: String, port: Int): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(0x00) // version
        out.write(uuidToBytes(config.uuid)) // UUID ۱۶ بایت
        out.write(0x00) // addon length = 0
        out.write(0x01) // command = TCP
        out.write((port ushr 8) and 0xff)
        out.write(port and 0xff)
        // آدرس: domain یا IP
        if (isIpv4(ip)) {
            out.write(0x01) // addr type = IPv4
            val parts = ip.split('.').map { it.toInt() }
            for (p in parts) out.write(p and 0xff)
        } else {
            out.write(0x02) // addr type = domain
            val domain = ip.toByteArray(Charsets.US_ASCII)
            out.write(domain.size and 0xff)
            out.write(domain)
        }
        return out.toByteArray()
    }

    private fun uuidToBytes(uuid: String): ByteArray {
        val hex = uuid.replace("-", "")
        val out = ByteArray(16)
        var i = 0
        for (c in hex) {
            if (i >= 16) break
            out[i] = c.digitToInt(16).toByte()
            i++
        }
        return out
    }

    private fun isIpv4(s: String): Boolean =
        s.matches(Regex("^\\d{1,3}(\\.\\d{1,3}){3}$"))
}
