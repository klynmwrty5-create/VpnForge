package com.vlessvpn

import android.app.Service
import android.content.Intent
import android.net.VpnService
import android.os.ParcelFileDescriptor
import android.util.Log

/**
 * سرویس VPN.衡阳ِ VPN را برقرار می‌کند و [VpnTcpStack] را روی آن اجرا می‌کند.
 */
class VlessVpnService : VpnService() {

    private var stack: VpnTcpStack? = null
    private var vpnFd: ParcelFileDescriptor? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val config = intent?.let { ConfigExtra.fromIntent(it) } ?: return START_NOT_STICKY

        val builder = Builder()
            .setSession("VpnForge")
            .addAddress("10.0.0.2", 24)      // IPِ衡阳ِ برای اپ‌ها
            .addRoute("0.0.0.0", 0)           // همه ترافیک از衡阳 می‌گذرد
            .addDnsServer("10.0.0.1")        // DNSِ衡阳
            .setMtu(1500)

        vpnFd = builder.establish() ?: run {
            notifyState("VPN برقرار نشد (اجازه VPN داده نشد)")
            stopSelf()
            return START_NOT_STICKY
        }

        stack = VpnTcpStack(vpnFd!!, config, DNS_SERVER, onStatus = { msg ->
            Log.i(TAG, msg)
            notifyState(msg)
        }).also { it.start() }

        notifyState("اتصال برقرار شد — ${config.name}")
        return START_STICKY
    }

    override fun onDestroy() {
        super.onDestroy()
        stack?.stop()
        stack = null
        try {
            vpnFd?.close()
        } catch (_: Exception) {
        }
        vpnFd = null
        notifyState("اتصال قطع شد")
    }

    override fun onRevoke() {
        super.onRevoke()
        notifyState("VPN توسط سیستم لغو شد")
        stopSelf()
    }

    private fun notifyState(msg: String) {
        Listener?.onVpnState(msg)
    }

    companion object {
        private const val TAG = "VlessVpnService"
        const val DNS_SERVER = "8.8.8.8"

        /** callback برای اطلاع‌رسانی وضعیت به MainActivity */
        @Volatile
        var Listener: ((String) -> Unit)? = null
    }
}

/** انتقال ServerConfig از Intent (به‌صورت strings) */
object ConfigExtra {
    const val EX_NAME = "name"
    const val EX_SERVER = "server"
    const val EX_PORT = "port"
    const val EX_UUID = "uuid"
    const val EX_PATH = "path"
    const val EX_TLS = "tls"
    const val EX_HOST = "host"

    fun fromIntent(intent: Intent): ServerConfig = ServerConfig(
        name = intent.getStringExtra(EX_NAME) ?: "",
        server = intent.getStringExtra(EX_SERVER) ?: "",
        port = intent.getIntExtra(EX_PORT, 443),
        uuid = intent.getStringExtra(EX_UUID) ?: "",
        path = intent.getStringExtra(EX_PATH) ?: "/",
        tls = intent.getBooleanExtra(EX_TLS, true),
        host = intent.getStringExtra(EX_HOST)
    )

    fun toIntent(intent: Intent, config: ServerConfig): Intent = intent
        .putExtra(EX_NAME, config.name)
        .putExtra(EX_SERVER, config.server)
        .putExtra(EX_PORT, config.port)
        .putExtra(EX_UUID, config.uuid)
        .putExtra(EX_PATH, config.path)
        .putExtra(EX_TLS, config.tls)
        .apply {
            if (config.host != null) putExtra(EX_HOST, config.host)
        }
}
