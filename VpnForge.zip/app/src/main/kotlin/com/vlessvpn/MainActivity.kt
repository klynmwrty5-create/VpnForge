package com.vlessvpn

import android.content.Intent
import android.net.VpnService
import android.os.Bundle
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.ListView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity

/**
 * صفحه اصلی: لیست سرورهای内置 + دکمه اتصال/قطع + وضعیت.
 */
class MainActivity : AppCompatActivity() {

    private lateinit var servers: List<ServerConfig>
    private var selectedIndex = 0
    private var connected = false

    private lateinit var listView: ListView
    private lateinit var btnConnect: Button
    private lateinit var tvStatus: TextView
    private lateinit var tvDetail: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        listView = findViewById(R.id.serverList)
        btnConnect = findViewById(R.id.btnConnect)
        tvStatus = findViewById(R.id.tvStatus)
        tvDetail = findViewById(R.id.tvDetail)

        servers = runCatching { ServerConfigLoader.load(this) }.getOrElse {
            emptyList()
        }

        listView.adapter = ArrayAdapter(
            this, android.R.layout.simple_list_item_checked,
            servers.map { it.name }
        )
        listView.choiceMode = ListView.CHOICE_MODE_SINGLE
        listView.setItemChecked(0, true)
        listView.setOnItemClickListener { _, _, position, _ ->
            selectedIndex = position
            updateDetail()
        }

        btnConnect.setOnClickListener {
            if (connected) {
                disconnect()
            } else {
                connect()
            }
        }

        // دریافت وضعیت از سرویس
        VlessVpnService.Listener = { msg ->
            runOnUiThread {
                tvStatus.text = msg
                if (msg.contains("اتصال برقرار شد") || msg.contains("VPN برقرار")) {
                    connected = true
                }
                if (msg.contains("اتصال قطع شد") || msg.contains("لغو")) {
                    connected = false
                }
                btnConnect.text = if (connected) "قطع اتصال" else "اتصال"
            }
        }

        updateDetail()
    }

    private fun updateDetail() {
        val cfg = servers.getOrNull(selectedIndex)
        tvDetail.text = if (cfg != null) {
            "سرور: ${cfg.name}\n${cfg.server}:${cfg.port}\nبرنامه: ${cfg.wsUrl()}"
        } else {
            "سرور Available نیست"
        }
    }

    private fun connect() {
        val cfg = servers.getOrNull(selectedIndex) ?: return
        // بررسی/درخواست اجازه VPN
        val prepareIntent = VpnService.prepare(this)
        if (prepareIntent != null) {
            startActivityForResult(prepareIntent, REQUEST_VPN)
        } else {
            startVpn(cfg)
        }
    }

    private fun startVpn(cfg: ServerConfig) {
        val intent = Intent(this, VlessVpnService::class.java)
        ConfigExtra.toIntent(intent, cfg)
        startService(intent)
        tvStatus.text = "در حال اتصال..."
    }

    private fun disconnect() {
        stopService(Intent(this, VlessVpnService::class.java))
        connected = false
        btnConnect.text = "اتصال"
        tvStatus.text = "قطع شد"
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == REQUEST_VPN) {
            if (resultCode == RESULT_OK) {
                val cfg = servers.getOrNull(selectedIndex)
                if (cfg != null) startVpn(cfg)
            } else {
                tvStatus.text = "اجازه VPN رد شد"
            }
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        VlessVpnService.Listener = null
    }

    companion object {
        private const val REQUEST_VPN = 1001
    }
}
