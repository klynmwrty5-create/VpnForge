package com.vlessvpn

import android.os.ParcelFileDescriptor
import java.io.ByteArrayOutputStream
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.random.Random

/**
 * یک stackِ TCP/IPو IPv4 روی衡阳ِ VPN.
 *
 * کار: از衡阳ِ VPN (TUN) پک‌های IP می‌خواند، اتصالات TCP را به صورت
 * ترافیکِโปรکسی (SYN-ACK ساختگی + تونل VLESS) به سرور می‌فرستد، و
 * پاسخ را به صورت پک‌های TCP/IP واقعی برای اپ‌ها می‌سازد.
 *
 * محدودیت v1:
 *  - فقط IPv4 (IPv6 پک‌ها رد می‌شوند — اپ‌ها به IPv4 fallback می‌کنند)
 *  - UDP فقط برای DNS (پورت 53) — چون سرور کلادفلر فقط TCP دارد
 *  - ICMP پشتیبانی نمی‌شود
 */
class VpnTcpStack(
    private val vpnFd: ParcelFileDescriptor,
    private val config: ServerConfig,
    private val dnsServer: String,
    private val onStatus: (String) -> Unit
) {
    private val appIp = 0x0A000002 // ۱۰.۰.۰.۲ — IPِ衡阳ِ برای اپ‌ها
    private val dnsIp = 0x0A000001 // ۱۰.۰.۰.۱ — IPِ DNSِ衡阳

    private val input = FileInputStream(vpnFd.fileDescriptor)
    private val output = FileOutputStream(vpnFd.fileDescriptor)
    private val outLock = Any()
    private val running = AtomicBoolean(true)
    private val executor = Executors.newFixedThreadPool(8)

    private val connTable = ConcurrentHashMap<String, TcpConn>()
    private var pending = ByteArray(0)
    private var packetId = 1

    private enum class State { SYN_RECEIVED, ESTABLISHED, FIN_WAIT, CLOSED }

    /** شروع loopِ پک‌ها */
    fun start() {
        Thread(::loop, "vpn-packet-loop").start()
    }

    fun stop() {
        running.set(false)
        try {
            input.close()
        } catch (_: Exception) {
        }
        executor.shutdownNow()
        connTable.values.forEach { it.close() }
        connTable.clear()
    }

    private fun loop() {
        val buf = ByteArray(32768)
        while (running.get()) {
            try {
                val n = input.read(buf)
                if (n <= 0) {
                    if (!running.get()) break
                    Thread.sleep(10)
                    continue
                }
                pending = pending + buf.copyOfRange(0, n)
                while (pending.isNotEmpty()) {
                    val pktLen = packetLength(pending, 0)
                    if (pktLen <= 0 || pktLen > pending.size) break // ناقص است، ادامه می‌خوانیم
                    handlePacket(pending, 0, pktLen)
                    pending = pending.copyOfRange(pktLen, pending.size)
                }
            } catch (e: IOException) {
                if (!running.get()) break
            } catch (_: Exception) {
                // پک‌های ناقص/بی‌معنا: بی‌خیال
            }
        }
    }

    /** اندازه پکِ کامل (بر اساس سر شری IP)، یا -1 برای پکِ ناقص */
    private fun packetLength(b: ByteArray, off: Int): Int {
        if (off >= b.size) return -1
        val version = (b[off].toInt() ushr 4) and 0x0f
        return if (version == 4) {
            if (off + 4 > b.size) return -1
            val ihl = (b[off] and 0x0f) * 4
            ((b[off + 2].toInt() and 0xff) shl 8) or (b[off + 3].toInt() and 0xff)
        } else if (version == 6) {
            if (off + 6 > b.size) return -1
            40 + (((b[off + 4].toInt() and 0xff) shl 8) or (b[off + 5].toInt() and 0xff))
        } else -1
    }

    private fun handlePacket(b: ByteArray, off: Int, pktLen: Int) {
        val b0 = b[off].toInt() and 0xff
        val version = b0 ushr 4
        if (version != 4) {
            // IPv6 در v1 غیرفعال است — پک رد می‌شود
            return
        }
        val ihl = (b0 and 0x0f) * 4
        val proto = b[off + 9].toInt() and 0xff
        val srcIp = readIntBE(b, off + 12)
        val dstIp = readIntBE(b, off + 16)
        val l4 = off + ihl
        val l4Len = (pktLen - ihl).coerceAtLeast(0)
        when (proto) {
            6 -> handleTcp(b, l4, l4Len, srcIp, dstIp)
            17 -> handleUdp(b, l4, l4Len, srcIp, dstIp)
        }
    }

    // ───────────────────────────── TCP ─────────────────────────────

    private fun handleTcp(b: ByteArray, off: Int, len: Int, srcIp: Int, dstIp: Int) {
        if (len < 20) return
        val sport = readShortBE(b, off)
        val dport = readShortBE(b, off + 2)
        val seq = readLongBE(b, off + 4)
        val dataOff = (b[off + 12].toInt() ushr 4) * 4
        val flags = b[off + 13].toInt() and 0xff
        val payloadOff = off + dataOff
        val payloadLen = (len - dataOff).coerceAtLeast(0)
        val payload = if (payloadLen > 0) b.copyOfRange(payloadOff, payloadOff + payloadLen) else ByteArray(0)
        val key = "$srcIp:$sport"
        val conn = connTable[key]

        if (conn == null && (flags and FLAG_SYN) != 0) {
            // SYN جدید: ساخت کانکشون + SYN-ACK + باز کردن تونل
            val c = TcpConn(key, srcIp, sport, dstIp, dport, seq)
            connTable[key] = c
            sendSynAck(c)
            openTunnel(c)
        } else if (conn != null) {
            conn.handleSegment(flags, seq, payload)
        }
    }

    private fun sendSynAck(conn: TcpConn) {
        // SYN-ACK ساختگی: seq = ISN، ack = appSeq + 1
        conn.serverNextSeq = conn.isn + 1
        val seg = buildTCP(
            srcIp = conn.dstIp, dstIp = conn.appIp,
            sport = conn.dport, dport = conn.sport,
            seq = conn.isn, ack = conn.appSeq + 1,
            flags = FLAG_SYN or FLAG_ACK, payload = ByteArray(0)
        )
        writeOut(seg)
    }

    private fun openTunnel(conn: TcpConn) {
        executor.execute {
            val tunnel = VlessTunnel(
                config,
                ipToString(conn.dstIp),
                conn.dstPort,
                onData = { data -> deliverToApp(conn, data) },
                onClose = { tunnelClosed(conn) }
            )
            conn.tunnel = tunnel
            val ok = tunnel.connect()
            if (!ok) {
                onStatus("اتصال به سرور برאין می‌شود: ${conn.dstIpStr()}")
                sendRst(conn)
                connTable.remove(conn.key)
                tunnel.close()
            }
        }
    }

    private fun deliverToApp(conn: TcpConn, data: ByteArray) {
        if (conn.state == State.CLOSED) return
        val seg = buildTCP(
            srcIp = conn.dstIp, dstIp = conn.appIp,
            sport = conn.dport, dport = conn.sport,
            seq = conn.serverNextSeq, ack = conn.appNextSeq,
            flags = FLAG_PSH or FLAG_ACK, payload = data
        )
        conn.serverNextSeq += data.size
        writeOut(seg)
    }

    private fun sendFin(conn: TcpConn) {
        conn.flushPending()
        conn.finSentToApp = true
        conn.state = State.FIN_WAIT
        val seg = buildTCP(
            srcIp = conn.dstIp, dstIp = conn.appIp,
            sport = conn.dport, dport = conn.sport,
            seq = conn.serverNextSeq, ack = conn.appNextSeq,
            flags = FLAG_FIN or FLAG_ACK, payload = ByteArray(0)
        )
        writeOut(seg)
        // بستنِ تونل تا FIN را به سرور واقعی برسانیم
        conn.tunnel?.close()
    }

    private fun sendRst(conn: TcpConn) {
        conn.state = State.CLOSED
        val seg = buildTCP(
            srcIp = conn.dstIp, dstIp = conn.appIp,
            sport = conn.dport, dport = conn.sport,
            seq = 0, ack = conn.appNextSeq,
            flags = FLAG_RST or FLAG_ACK, payload = ByteArray(0)
        )
        writeOut(seg)
    }

    private fun tunnelClosed(conn: TcpConn) {
        if (!conn.finSentToApp) {
            conn.finSentToApp = true
            conn.state = State.CLOSED
            val seg = buildTCP(
                srcIp = conn.dstIp, dstIp = conn.appIp,
                sport = conn.dport, dport = conn.sport,
                seq = conn.serverNextSeq, ack = conn.appNextSeq,
                flags = FLAG_FIN or FLAG_ACK, payload = ByteArray(0)
            )
            writeOut(seg)
        }
        connTable.remove(conn.key)
    }

    // ───────────────────────────── UDP / DNS ─────────────────────────────

    private fun handleUdp(b: ByteArray, off: Int, len: Int, srcIp: Int, dstIp: Int) {
        if (len < 8) return
        val sport = readShortBE(b, off)
        val dport = readShortBE(b, off + 2)
        val payloadLen = (len - 8).coerceAtLeast(0)
        if (dport == 53 && payloadLen > 0) {
            val query = b.copyOfRange(off + 8, off + 8 + payloadLen)
            handleDnsQuery(srcIp, sport, dstIp, dport, query)
        }
    }

    /** DNS query از اپ → از تونل VLESS (TCP) به سرور DNS واقعی می‌رود، پاسخ برمی‌گردد */
    private fun handleDnsQuery(appIp: Int, sport: Int, dnsIp: Int, dport: Int, query: ByteArray) {
        executor.execute {
            val tunnel = VlessTunnel(
                config,
                dnsServer,
                53,
                onData = { data ->
                    // پاسخ DNS را به اپ به صورت UDP برمی‌گردانیم
                    val resp = buildUDP(dnsIp, appIp, dport, sport, data)
                    writeOut(resp)
                    tunnel.close()
                },
                onClose = {}
            )
            if (tunnel.connect()) {
                tunnel.send(query)
            } else {
                tunnel.close()
            }
        }
    }

    // ─────────────────────────── ساخت پک‌ها ───────────────────────────

    private fun buildIPv4(src: Int, dst: Int, proto: Int, payload: ByteArray): ByteArray {
        val hlen = 20
        val tlen = hlen + payload.size
        val out = ByteArray(tlen)
        out[0] = 0x45
        out[1] = 0
        writeShortBE(out, 2, tlen)
        out[4] = 0
        out[5] = 0
        writeShortBE(out, 6, (packetId++ and 0xffff))
        out[8] = 64
        out[9] = proto.toByte()
        out[10] = 0
        out[11] = 0
        writeIntBE(out, 12, src)
        writeIntBE(out, 16, dst)
        writeShortBE(out, 10, checksum(out, 0, hlen))
        System.arraycopy(payload, 0, out, hlen, payload.size)
        return out
    }

    private fun buildTCP(
        srcIp: Int, dstIp: Int, sport: Int, dport: Int,
        seq: Long, ack: Long, flags: Int, payload: ByteArray
    ): ByteArray {
        val hlen = 20
        val tlen = hlen + payload.size
        val tcp = ByteArray(tlen)
        writeShortBE(tcp, 0, sport)
        writeShortBE(tcp, 2, dport)
        writeLongBE(tcp, 4, seq)
        writeLongBE(tcp, 8, ack)
        tcp[12] = (hlen shr 4).toByte()
        tcp[13] = flags.toByte()
        writeShortBE(tcp, 14, 65535) // window
        tcp[16] = 0
        tcp[17] = 0
        tcp[18] = 0
        tcp[19] = 0
        val ck = tcpChecksum(srcIp, dstIp, tcp)
        tcp[16] = (ck ushr 8).toByte()
        tcp[17] = ck.toByte()
        return buildIPv4(srcIp, dstIp, 6, tcp)
    }

    private fun buildUDP(srcIp: Int, dstIp: Int, sport: Int, dport: Int, payload: ByteArray): ByteArray {
        val hlen = 8
        val udp = ByteArray(hlen + payload.size)
        writeShortBE(udp, 0, sport)
        writeShortBE(udp, 2, dport)
        writeShortBE(udp, 4, (hlen + payload.size))
        udp[6] = 0
        udp[7] = 0 // checksum 0 (مجاز در IPv4)
        System.arraycopy(payload, 0, udp, hlen, payload.size)
        return buildIPv4(srcIp, dstIp, 17, udp)
    }

    private fun tcpChecksum(srcIp: Int, dstIp: Int, tcp: ByteArray): Int {
        val buf = ByteArray(12 + tcp.size)
        writeIntBE(buf, 0, srcIp)
        writeIntBE(buf, 4, dstIp)
        buf[8] = 0
        buf[9] = 0
        buf[10] = 6
        buf[11] = 0
        writeShortBE(buf, 12, tcp.size)
        System.arraycopy(tcp, 0, buf, 12, tcp.size)
        return checksum(buf, 0, buf.size)
    }

    private fun checksum(data: ByteArray, offset: Int, length: Int): Int {
        var sum = 0L
        var i = offset
        while (i < offset + length - 1) {
            sum += ((data[i].toInt() and 0xff) shl 8) or (data[i + 1].toInt() and 0xff)
            i += 2
        }
        if (length % 2 == 1) sum += (data[offset + length - 1].toInt() and 0xff) shl 8
        while ((sum ushr 16) != 0) sum = (sum and 0xffff) + (sum ushr 16)
        return (sum.inv() and 0xffff).toInt()
    }

    private fun writeOut(packet: ByteArray) {
        synchronized(outLock) {
            try {
                output.write(packet)
                output.flush()
            } catch (_: Exception) {
            }
        }
    }

    private fun ipToString(ip: Int): String =
        "${(ip ushr 24) and 0xff}.${(ip ushr 16) and 0xff}.${(ip ushr 8) and 0xff}.${ip and 0xff}"

    // ─────────────────── helpersِ big-endian ───────────────────

    private fun readIntBE(b: ByteArray, o: Int): Int =
        ((b[o].toInt() and 0xff) shl 24) or ((b[o + 1].toInt() and 0xff) shl 16) or
            ((b[o + 2].toInt() and 0xff) shl 8) or (b[o + 3].toInt() and 0xff)

    private fun readShortBE(b: ByteArray, o: Int): Int =
        ((b[o].toInt() and 0xff) shl 8) or (b[o + 1].toInt() and 0xff)

    private fun readLongBE(b: ByteArray, o: Int): Long =
        ((b[o].toLong() and 0xff) shl 56) or ((b[o + 1].toLong() and 0xff) shl 48) or
            ((b[o + 2].toLong() and 0xff) shl 40) or ((b[o + 3].toLong() and 0xff) shl 32) or
            ((b[o + 4].toLong() and 0xff) shl 24) or ((b[o + 5].toLong() and 0xff) shl 16) or
            ((b[o + 6].toLong() and 0xff) shl 8) or (b[o + 7].toLong() and 0xff)

    private fun writeIntBE(b: ByteArray, o: Int, v: Int) {
        b[o] = (v ushr 24).toByte()
        b[o + 1] = (v ushr 16).toByte()
        b[o + 2] = (v ushr 8).toByte()
        b[o + 3] = v.toByte()
    }

    private fun writeShortBE(b: ByteArray, o: Int, v: Int) {
        b[o] = (v ushr 8).toByte()
        b[o + 1] = v.toByte()
    }

    private fun writeLongBE(b: ByteArray, o: Int, v: Long) {
        b[o] = (v ushr 56).toByte()
        b[o + 1] = (v ushr 48).toByte()
        b[o + 2] = (v ushr 40).toByte()
        b[o + 3] = (v ushr 32).toByte()
        b[o + 4] = (v ushr 24).toByte()
        b[o + 5] = (v ushr 16).toByte()
        b[o + 6] = (v ushr 8).toByte()
        b[o + 7] = v.toByte()
    }

    // ─────────────────── کُنکشنِ TCP ───────────────────

    private inner class TcpConn(
        val key: String,
        val appIp: Int,
        val sport: Int,
        val dstIp: Int,
        val dstPort: Int,
        appSeq: Long
    ) {
        val isn = Random.nextLong(1, 0x7fffffffL)
        var appSeq = appSeq
        var appNextSeq = appSeq + 1
        var serverNextSeq = isn + 1
        var state = State.SYN_RECEIVED
        var tunnel: VlessTunnel? = null
        var finSentToApp = false
        val pendingOut = ByteArrayOutputStream()

        fun dstIpStr() = ipToString(dstIp)

        fun handleSegment(flags: Int, seq: Long, payload: ByteArray) {
            if ((flags and FLAG_RST) != 0) {
                close()
                connTable.remove(key)
                return
            }
            when (state) {
                State.SYN_RECEIVED -> {
                    if ((flags and FLAG_ACK) != 0 && (flags and FLAG_SYN) == 0) {
                        state = State.ESTABLISHED
                        flushPending()
                    }
                }
                State.ESTABLISHED -> {
                    if (payload.isNotEmpty()) {
                        if (tunnel != null) tunnel!!.send(payload) else pendingOut.write(payload)
                    }
                    if ((flags and FLAG_FIN) != 0) {
                        sendFin(this)
                    }
                }
                State.FIN_WAIT -> { /* تمدید قطع */ }
                State.CLOSED -> { }
            }
        }

        fun flushPending() {
            val tunnel = this.tunnel ?: return
            if (pendingOut.size() > 0) {
                tunnel.send(pendingOut.toByteArray())
                pendingOut.reset()
            }
        }

        fun close() {
            tunnel?.close()
        }
    }

    companion object {
        private const val FLAG_FIN = 0x01
        private const val FLAG_SYN = 0x02
        private const val FLAG_RST = 0x04
        private const val FLAG_PSH = 0x08
        private const val FLAG_ACK = 0x10
    }
}
