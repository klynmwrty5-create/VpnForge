package com.vlessvpn

import android.content.Context
import org.json.JSONArray

/**
 * یک سرور VLESS (همان سرور کلادفلرِ ساخته شده).
 * اطلاعات از assets/servers.json در سفید می‌شود.
 */
data class ServerConfig(
    val name: String,
    val server: String,        // domain یا IP سرور (مثل vpn.example.com)
    val port: Int = 443,
    val uuid: String,
    val path: String,          // مسیر WebSocket (WS_PATH سرور)
    val tls: Boolean = true,   // wss (tls=true) یا ws
    val host: String? = null   // SNI / Host header،如果要 متفاوت از server است
) {
    /** URL WebSocket برای اتصال客户端 به سرور */
    fun wsUrl(): String {
        val scheme = if (tls) "wss" else "ws"
        return "$scheme://${host ?: server}:$port$path"
    }
}

/** بارگذاری لیست سرورهای内置 از assets */
object ServerConfigLoader {

    fun load(context: Context): List<ServerConfig> {
        val text = context.assets.open("servers.json").bufferedReader().use { it.readText() }
        val arr = JSONArray(text)
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            ServerConfig(
                name = o.getString("name"),
                server = o.getString("server"),
                port = o.optInt("port", 443),
                uuid = o.getString("uuid"),
                path = o.getString("path"),
                tls = o.optBoolean("tls", true),
                host = if (o.has("host") && !o.isNull("host")) o.getString("host") else null
            )
        }
    }
}
