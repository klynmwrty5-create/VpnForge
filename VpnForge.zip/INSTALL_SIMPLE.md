# راهنمای نصبِ سادهِ اپِ VpnForge (قدم‌به‌قدم)

این راهنما، روند نصبِ اپِ **VpnForge** روی گوشی را به **زبانی ساده** و **قدم‌به‌قدم** توضیح می‌دهد. فقط مراحل را دنبال کن.

---

## نام اپ

**VpnForge** — یک اپِ VPNِ أندرویدی، با سرورهای خودش (سرورهای کلادفلر).

---

## قدم ۱ — فایل zip را دانلود و باز کن

1. فایلِ **`VpnForge.zip`** را دانلود کن.
2. آن را **extract (باز کردن)** کن — یک folderِ **`VpnForge`** برایت ساخته می‌شود.
3. آن folder را باز کن — تمامِ فایل‌های اپ را می‌بینی.

> تمامِ فایل‌ها داخل همین folder هستند. نیازی به پیدا کردنya دیگر نداری.

---

## قدم ۲ — گیت‌هاب را آماده کن

1. سایتِ **github.com** را باز کن و وارد accountِ خود شوی.
2. گلوگیری **New repository** بزن.
   - **Name**: `VpnForge`
   - **Public** یا **Private** را انتخاب کن (برای استفاده شخصی، Private هم می‌تواند).
3. repository را با کلیک روی **Create** بساز.

> حالا یک مجلِ گیت‌هاب برای اپت آماده است.

---

## قدم ۳ — پروژه را به گیت‌هاب بفرست

این مراحل را روی کامپیوترِ خود (command line / Terminal) انجام کن:

1. command line را باز کن و به داخلِ folderِ `VpnForge` برود:

   ```bash
   cd /مسیر/VpnForge
   ```

   (مسیرِ folderی را که extract کردی جایمسیر قرار بده)

2. project را به گیت‌هاب معرفی کن و بفرست:

   ```bash
   git init
   git add .
   git commit -m "VpnForge اولیه"
   git remote add origin https://github.com/<username>/VpnForge.git
   git branch -M main
   git push -u origin main
   ```

   (`<username>` را با نام کاربری گیت‌هابِ خود جایگزین کن)

> ✅ حالا تمامِ فایل‌ها روی گیت‌هاب هستند و everyone می‌تواند آن‌ها را ببیند (يا فقط خودت، طبقِ Private).

---

## قدم ۴ — APK را با Android Studio بساز

**APK** همان فایلِ نصب‌پذیرِ اپ است. برای ساخت آن:

1. **Android Studio** را نصب و باز کن (اگر نداری، از Android Studio و نصب کن).
2. در Android Studio: **File → Open** → folderِ `VpnForge` را انتخاب کن.
3. چند دقیقه‌ای بماند — Android Studio prepare می‌کند (dependencies را Lad می‌کند).
4. بعد از کامل شدن، از منو:

   **Build → Build Bundle(s)/APK(s) → Build APK(s)**

5. منتظر بمان تا پیام **"Build: Completed"** بیاید.
6. فایلِ APK اینجاست:

   ```
   VpnForge/app/build/outputs/apk/debug/app-debug.apk
   ```

> ✅ حالا یک فایلِ `app-debug.apk` داری که می‌توانی روی گوشی نصبش کنی.

---

## قدم ۵ — APK را به گیت‌هاب بگذار (Release)

برای اینکه کاربرها بتوانند APK را مستقیم از گیت‌هاب دانلود کنند:

1. گیت‌هاب → پروژه (`VpnForge`) → **Releases** → **Draft a new release**.
2. **Tag**: `v1.0` بنویس.
3. **Release title**: `VpnForge v1.0`.
4. در بخشِ **Attach binaries**:
   - روی **Choose an existing asset** بزن (يا فایل APK را در آن منطقه Drag کن).
   - فایلِ `app-debug.apk` که در قدم ۴ ساختی را انتخاب کن.
5. **Publish release** بزن.

> ✅ حالا لینکِ دانلودِ مستقیمِ APK برایت شده:
> `https://github.com/<username>/VpnForge/releases/download/v1.0/app-debug.apk`

---

## قدم ۶ — روی گوشی دانلود و نصب کن

1. روی گوشی، مرورگر را باز کن و لینکِ Release را باز کن:

   ```
   https://github.com/<username>/VpnForge/releases
   ```

2. روی **Download** (یا نام فایل APK) بزن — APK دانلود می‌شود.
3. اگر پیامِ **«منبعِ ناشناخته / Unknown sources»** آمد:
   - روی **Settings** / **Install anyway** بزن.
   - اجازهِ **«نصب از این منبع»** را بده.
4. روی **Install** بزن. نصب تمام می‌شود.

> 💡 اگر نصب نشد: تنظیمات → امنیت → مجوزِ **«نصب از منابعِ ناشناخته»** را برای مرورگرِ خود فعال کن.

---

## قدم ۷ — سرورها را تنظیم کن و وصل شو

1. روی کامپیوتر، فایلِ **`app/src/main/assets/servers.json`** را باز کن.
2. سرورهای کلادفلرِ خودت را در آن بنویس:

   ```json
   [
     {
       "name": "سرور ۱",
       "server": "vpn.example.com",
       "port": 443,
       "uuid": "يزينة UUIDِ سرور کلادفلر",
       "path": "/k9x2-vless-tunnel-7f3a",
       "tls": true,
       "host": "vpn.example.com"
     }
   ]
   ```

   (`uuid`، `path`، `server` را با قدرهای سرور کلادفلرِ خودت جایگزین کن)

3. دوباره APK را بسازی (قدم ۴) و روی گوشی نصب کن (قدم ۶).
4. اپِ **VpnForge** را باز کن → سرور را انتخاب کن → دکمه‌ی **اتصال (power)** → اجازهِ VPN را بده.

> ✅ حالا VPNِ تو فعال است.

---

## خلاصهِ کوتاه

1. zip را دانلود و extract کن.
2. گیت‌هاب بسازی و پروژه را push کن.
3. با Android Studio، APK بسازی.
4. APK را به یک Release در گیت‌هاب بگذار.
5. روی گوشی، APK را دانلود و نصب کن.
6. در `servers.json`، سرورها را بنویس، دوباره بساز و وصل شو.

---

## نکات ساده

- **debug APK** برای نصبِ شخصی کافی است.
- اگر در buildِ Android Studio یا pushِ گیت‌هاب سوال داشتی، هر قدم را با من بگو تا کمک کنم.
- فایلِ **`INSTALL.md`** هم در پروژه، آموزشِ کامل‌ترِ قدم‌به‌قدم دارد.
