# VpnForge — اپ اندروید، صفحه اصلی و سرورهای داخلی (built-in)

اپِ **VpnForge** — اپِ اندرویدی با **صفحه اصلی** (همان شکلِ V2Ray/VLESS) و
**کانفیگ‌های مختص هر فرد** (هر گوشی مجموعه سرور و UUIDِ مجزا دارد)، سرورها روی **کلادفلر**.

## ساختار پروژه

```
vlessvpn/                       (نام کالبدی پروژه؛ اپ خود، برند VpnForge است)
├── home.html                   ← صفحه اصلی/پیش‌فرض اپ (HTML، standalone)
├── settings.gradle.kts
├── build.gradle.kts
├── gradle.properties
├── gradle/wrapper/gradle-wrapper.properties
└── app/
    ├── build.gradle.kts
    └── src/main/
        ├── AndroidManifest.xml      # پرمیسین‌ها + سرویس VPN
        ├── assets/
        │   └── servers.json         # سرورهای داخلی (built-in) (هر کدام یک سرور کلادفلر)
        ├── kotlin/com/vlessvpn/
        │   ├── MainActivity.kt      # صفحه اصلی: لیست سرور + اتصال/قطع
        │   ├── VlessVpnService.kt   # سرویس VPN (VpnService) — session: VpnForge
        │   ├── VpnTcpStack.kt       # stackِ TCP/IP + تونل VLESS
        │   ├── VlessTunnel.kt       # client VLESS-over-WebSocket
        │   └── ServerConfig.kt      # مدل سرور + بارگذاری از assets
        └── res/
            ├── layout/activity_main.xml
            └── values/ (strings: app_name=VpnForge, colors, themes)
```

## صفحه اصلی (home.html)

صفحه اصلی/پیش‌فرض اپ به‌صورتِ HTMLِ standalone (inline CSS/JS، بدون external resource):

- logo و نام اپ (**VpnForge**)
- **انتخاب کاربر (profilِ مختص فرد)**
- **دکمه اتصال/قطع** + وضعیتِ زنده
- **لیست سرورهای این کاربر** — هر سرور: نام، host، path، UUIDِ مختص فرد، دکمه وصل شدن + کپی لینک

**کانفیگ بر اساس هر فرد**: هر profil (گوشی/کاربر) مجموعه سرور و UUIDِ منحصربه‌فرد خودش را دارد —
سرورها از دیگر کاربران متفاوت است، دقیقاً مثل اپِ VLESS. نمونه اولیه دو کاربر (علی، فاطمه) با
چند سرورِ مجزا دارد. داده‌ها در `localStorage` نگه می‌شوند.

صفحه اصلی را در اپ به دو شکل استفاده می‌شود:
- به‌صورتِ **WebView** در `MainActivity`
- یا الگوبرداری از طرح آن در `res/layout/activity_main.xml`

## نحوه کار (اپ)

1. **سرور کلادفلر را deployment کن** (همون پروژه `cf-vless-vpn`)، WS_PATH و domainت را بدار.
   Worker چند‌کاربره است: هر UUIDِ مختص فرد را در لیست `UUIDS` قرار می‌دهی.
2. **سرورهای مختص هر فرد را در `app/src/main/assets/servers.json` بنویس** — هر سرور یک entry:

   ```json
   [
     {
       "name": "سرور ۱",
       "server": "vpn.example.com",
       "port": 443,
       "uuid": "يزينة UUIDِ مختص این فرد",
       "path": "/k9x2-vless-tunnel-7f3a",
       "tls": true,
       "host": "vpn.example.com"
     }
   ]
   ```
   می‌توانی چندین سرور بیفزایی. برای هر فرد، مجموعه UUIDِ خودش را استفاده کن.

3. **در Android Studio باز کن** → Gradle sync → **Build**. (Android Studio خودِ wrapper
   و SDK را مدیریت می‌کند؛ محیط این sandbox فقط فایل‌های پروژه را chứا SDK ندارد.)
4. **برنامه را نصب کن** → سرور را انتخاب کن → دکمه **اتصال** → اجازه VPN را بده.

## نحوه کار فنی

```
اپ‌ها (وب، تلگرام، ...)
    →interfaceِ VPN (VpnService / TUN)
    → VpnTcpStack: پک‌های TCP/IPv4 را می‌خواند
    → اتصالات TCP: SYN-ACK ساختگی + تونل VLESS-over-WebSocket
    → سرور کلادفلر (Worker) → مقصد واقعی
```

- **اتصالات اپ به سرور کلادفلر** توسط Android ازinterfaceِ VPN **استثنا** می‌شوند — بنابراین
  client WebSocketِ اپ (OkHttp) مستقیم به سرور می‌رسد و loop برقرار نمی‌شود.
- **TCP** کاملاً پشتیبانی می‌شود (همان stackِ TCP/IP با checksum).
- **UDP** فقط برای **DNS** (پورت ۵۳) پشتیبانی می‌شود — چون سرور کلادفلر فقط TCP دارد.
- **IPv6 و ICMP** در v1 پشتیبانی نمی‌شوند (اپ‌ها به IPv4 fallback می‌کنند).

## mapping به ساختار اپِ اصلی (APK)

| بخش اپِ اصلی | مقابل در این پروژه |
|---|---|
| `assets/` — سرورهای داخلی (built-in) | `app/src/main/assets/servers.json` |
| `kotlin/` — کد | `app/src/main/kotlin/com/vlessvpn/` |
| `res/` — UI | `app/src/main/res/` + `home.html` |
| `AndroidManifest.xml` — پرمیسین | `app/src/main/AndroidManifest.xml` |
| `classes.dex` — compiled | outputِ Gradle (apk) |
| Firebase analytics/ads | **اختیاری** — برای نسخه رایگان شخصی لازم نیست |
| billing (نسخه پولی) | **اختیاری** — قابل افزودن در آینده |

## محدودیت‌ها و نکات

- این پروژه در sandboxِ این محیط **قابل build نیست** (Android SDK ندارد)؛ باید در
  Android Studio open و build شود. کدِ منطق VLESS و stackِ TCP/IP مشترک با سرور کلادفلرِ
  تست‌شده است.
- برای **نسخه عمومی پایدار**، سرویس را به **foreground service** تبدیل کن و Firebase/ads
  و billing را آنگاه اضافه کن.
- تأمین‌کننده‌ی اینترنت و شرایط کلادفلر را رعایت کن (برای استفاده شخصی مشکلی ندارد).
