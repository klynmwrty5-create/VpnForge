package com.vlessvpn

import android.content.Context
import org.json.JSONArray

data class ServerConfig(
    val name: String,
    val server: String,
    val port: Int = 443,
    val uuid: String,
    val path: String,
    val tls: Boolean = true,
    val host: String? = null
) {
    fun wsUrl(): String {
        val scheme = if (tls) "wss" else "ws"
        val cleanPath = if (path.startsWith("/")) path else "/$path"
        return "$scheme://${host ?: server}:$port$cleanPath"
    }
}

object ServerConfigLoader {

    fun load(context: Context): List<ServerConfig> {
        val text = context.assets.open("servers.json").bufferedReader().use { it.readText() }
        val arr = JSONArray(text)
        return (0 until arr.length()).map { i ->
            val o = arr.getJSONObject(i)
            ServerConfig(
                name = o.getString("name"),
                server = o.getString("server"),
                port = o.optInt("port", 443),
                uuid = o.getString("uuid"),
                path = o.getString("path"),
                tls = o.optBoolean("tls", true),
                host = if (o.has("host") && !o.isNull("host")) o.getString("host") else null
            )
        }
    }
}
