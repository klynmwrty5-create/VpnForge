package com.vlessvpn

import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import okio.ByteString
import okio.ByteString.Companion.toByteString
import java.io.ByteArrayOutputStream
import java.util.concurrent.CountDownLatch
import java.util.concurrent.TimeUnit

class VlessTunnel(
    private val config: ServerConfig,
    private val target: String,
    private val port: Int,
    private val onData: (ByteArray) -> Unit,
    private val onClose: () -> Unit
) {
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(0, TimeUnit.MILLISECONDS)
        .build()

    @Volatile
    private var ws: WebSocket? = null
    private val headerLatch = CountDownLatch(1)
    private val pendingHeader = ByteArrayOutputStream()
    private var headerConsumed = false

    @Volatile
    private var closed = false

    fun connect(): Boolean {
        val header = buildVlessHeader(target, port)
        val reqBuilder = Request.Builder().url(config.wsUrl())
        if (!config.host.isNullOrBlank()) {
            reqBuilder.header("Host", config.host)
        }
        val request = reqBuilder.build()

        val socket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(webSocket: WebSocket, response: Response) {
                ws = webSocket
                webSocket.send(header.toByteString())
            }

            override fun onMessage(webSocket: WebSocket, text: String) {}

            override fun onMessage(webSocket: WebSocket, bytes: ByteString) {
                val data = bytes.toByteArray()
                if (!headerConsumed) {
                    synchronized(pendingHeader) {
                        pendingHeader.write(data)
                        if (pendingHeader.size() >= 2) {
                            headerConsumed = true
                            val all = pendingHeader.toByteArray()
                            pendingHeader.reset()
                            headerLatch.countDown()
                            if (all.size > 2) {
                                val rest = all.copyOfRange(2, all.size)
                                onData(rest)
                            }
                        }
                    }
                } else {
                    onData(data)
                }
            }

            override fun onClosing(webSocket: WebSocket, code: Int, reason: String) {
                webSocket.close(1000, null)
            }

            override fun onClosed(webSocket: WebSocket, code: Int, reason: String) {
                if (!closed) {
                    closed = true
                    headerLatch.countDown()
                    onClose()
                }
            }

            override fun onFailure(webSocket: WebSocket, t: Throwable, response: Response?) {
                if (!closed) {
                    closed = true
                    headerLatch.countDown()
                    onClose()
                }
            }
        })

        val ok = headerLatch.await(15, TimeUnit.SECONDS)
        if (!ok || closed) {
            socket.cancel()
            return false
        }
        return true
    }

    fun send(data: ByteArray) {
        ws?.send(data.toByteString())
    }

    fun close() {
        try {
            if (!closed) {
                closed = true
                ws?.close(1000, "client closing")
            }
        } catch (_: Exception) {}
    }

    private fun buildVlessHeader(ip: String, port: Int): ByteArray {
        val out = ByteArrayOutputStream()
        out.write(0x00)
        out.write(uuidToBytes(config.uuid))
        out.write(0x00)
        out.write(0x01)
        out.write((port ushr 8) and 0xff)
        out.write(port and 0xff)
        if (isIpv4(ip)) {
            out.write(0x01)
            val parts = ip.split('.').map { it.toInt() }
            for (p in parts) out.write(p and 0xff)
        } else {
            out.write(0x02)
            val domain = ip.toByteArray(Charsets.US_ASCII)
            out.write(domain.size and 0xff)
            out.write(domain)
        }
        return out.toByteArray()
    }

    private fun uuidToBytes(uuid: String): ByteArray {
        val hex = uuid.replace("-", "").trim()
        val out = ByteArray(16)
        if (hex.length < 32) return out
        for (i in 0 until 16) {
            val byteVal = hex.substring(i * 2, i * 2 + 2).toIntOrNull(16) ?: 0
            out[i] = byteVal.toByte()
        }
        return out
    }

    private fun isIpv4(s: String): Boolean =
        s.matches(Regex("^\\d{1,3}(\\.\\d{1,3}){3}$"))
}
