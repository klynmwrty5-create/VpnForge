package com.vlessvpn

import android.os.ParcelFileDescriptor
import java.io.ByteArrayOutputStream
import java.io.FileInputStream
import java.io.FileOutputStream
import java.io.IOException
import java.util.concurrent.ConcurrentHashMap
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicBoolean
import kotlin.random.Random

class VpnTcpStack(
    private val vpnFd: ParcelFileDescriptor,
    private val config: ServerConfig,
    private val dnsServer: String,
    private val onStatus: (String) -> Unit
) {
    private val input = FileInputStream(vpnFd.fileDescriptor)
    private val output = FileOutputStream(vpnFd.fileDescriptor)
    private val outLock = Any()
    private val running = AtomicBoolean(true)
    private val executor = Executors.newFixedThreadPool(8)

    private val connTable = ConcurrentHashMap<String, TcpConn>()
    private var pending = ByteArray(0)
    private var packetId = 1

    private enum class State { SYN_RECEIVED, ESTABLISHED, FIN_WAIT, CLOSED }

    fun start() {
        Thread(::loop, "vpn-packet-loop").start()
    }

    fun stop() {
        running.set(false)
        try { input.close() } catch (_: Exception) {}
        executor.shutdownNow()
        connTable.values.forEach { it.close() }
        connTable.clear()
    }

    private fun loop() {
        val buf = ByteArray(32768)
        while (running.get()) {
            try {
                val n = input.read(buf)
                if (n <= 0) {
                    if (!running.get()) break
                    Thread.sleep(10)
                    continue
                }
                pending = pending + buf.copyOfRange(0, n)
                while (pending.isNotEmpty()) {
                    val pktLen = packetLength(pending, 0)
                    if (pktLen <= 0 || pktLen > pending.size) break
                    handlePacket(pending, 0, pktLen)
                    pending = pending.copyOfRange(pktLen, pending.size)
                }
            } catch (e: IOException) {
                if (!running.get()) break
            } catch (_: Exception) {}
        }
    }

    private fun packetLength(b: ByteArray, off: Int): Int {
        if (off >= b.size) return -1
        val version = (b[off].toInt() ushr 4) and 0x0f
        return if (version == 4) {
            if (off + 4 > b.size) return -1
            ((b[off + 2].toInt() and 0xff) shl 8) or (b[off + 3].toInt() and 0xff)
        } else if (version == 6) {
            if (off + 6 > b.size) return -1
            40 + (((b[off + 4].toInt() and 0xff) shl 8) or (b[off + 5].toInt() and 0xff))
        } else -1
    }

    private fun handlePacket(b: ByteArray, off: Int, pktLen: Int) {
        val b0 = b[off].toInt() and 0xff
        val version = b0 ushr 4
        if (version != 4 || pktLen < 20) return
        val ihl = (b0 and 0x0f) * 4
        if (ihl < 20 || off + ihl > b.size) return
        val proto = b[off + 9].toInt() and 0xff
        val srcIp = readIntBE(b, off + 12)
        val dstIp = readIntBE(b, off + 16)
        val l4 = off + ihl
        val l4Len = (pktLen - ihl).coerceAtLeast(0)
        when (proto) {
            6 -> handleTcp(b, l4, l4Len, srcIp, dstIp)
            17 -> handleUdp(b, l4, l4Len, srcIp, dstIp)
        }
    }

    private fun handleTcp(b: ByteArray, off: Int, len: Int, srcIp: Int, dstIp: Int) {
        if (len < 20) return
        val sport = readShortBE(b, off)
        val dport = readShortBE(b, off + 2)
        val seq = readUInt32BE(b, off + 4)
        val dataOff = ((b[off + 12].toInt() and 0xff) ushr 4) * 4
        val flags = b[off + 13].toInt() and 0xff
        val payloadOff = off + dataOff
        val payloadLen = (len - dataOff).coerceAtLeast(0)
        val payload = if (payloadLen > 0 && payloadOff + payloadLen <= b.size) {
            b.copyOfRange(payloadOff, payloadOff + payloadLen)
        } else {
            ByteArray(0)
        }
        val key = "$srcIp:$sport->$dstIp:$dport"
        val conn = connTable[key]

        if (conn == null && (flags and FLAG_SYN) != 0) {
            val c = TcpConn(key, srcIp, sport, dstIp, dport, seq)
            connTable[key] = c
            sendSynAck(c)
            openTunnel(c)
        } else if (conn != null) {
            conn.handleSegment(flags, seq, payload)
        }
    }

    private fun sendSynAck(conn: TcpConn) {
        conn.serverNextSeq = conn.isn + 1
        val seg = buildTCP(
            srcIp = conn.dstIp, dstIp = conn.appIp,
            sport = conn.dport, dport = conn.sport,
            seq = conn.isn, ack = conn.appSeq + 1,
            flags = FLAG_SYN or FLAG_ACK, payload = ByteArray(0)
        )
        writeOut(seg)
    }

    private fun openTunnel(conn: TcpConn) {
        executor.execute {
            val tunnel = VlessTunnel(
                config,
                ipToString(conn.dstIp),
                conn.dport,
                onData = { data -> deliverToApp(conn, data) },
                onClose = { tunnelClosed(conn) }
            )
            conn.tunnel = tunnel
            val ok = tunnel.connect()
            if (!ok) {
                onStatus("خطا در اتصال به مقصد: ${conn.dstIpStr()}")
                sendRst(conn)
                connTable.remove(conn.key)
                tunnel.close()
            } else {
                conn.flushPending()
            }
        }
    }

    private fun deliverToApp(conn: TcpConn, data: ByteArray) {
        if (conn.state == State.CLOSED) return
        val seg = buildTCP(
            srcIp = conn.dstIp, dstIp = conn.appIp,
            sport = conn.dport, dport = conn.sport,
            seq = conn.serverNextSeq, ack = conn.appNextSeq,
            flags = FLAG_PSH or FLAG_ACK, payload = data
        )
        conn.serverNextSeq += data.size
        writeOut(seg)
    }

    private fun sendAck(conn: TcpConn) {
        val seg = buildTCP(
            srcIp = conn.dstIp, dstIp = conn.appIp,
            sport = conn.dport, dport = conn.sport,
            seq = conn.serverNextSeq, ack = conn.appNextSeq,
            flags = FLAG_ACK, payload = ByteArray(0)
        )
        writeOut(seg)
    }

    private fun sendFin(conn: TcpConn) {
        conn.flushPending()
        conn.finSentToApp = true
        conn.state = State.FIN_WAIT
        val seg = buildTCP(
            srcIp = conn.dstIp, dstIp = conn.appIp,
            sport = conn.dport, dport = conn.sport,
            seq = conn.serverNextSeq, ack = conn.appNextSeq,
            flags = FLAG_FIN or FLAG_ACK, payload = ByteArray(0)
        )
        writeOut(seg)
        conn.tunnel?.close()
    }

    private fun sendRst(conn: TcpConn) {
        conn.state = State.CLOSED
        val seg = buildTCP(
            srcIp = conn.dstIp, dstIp = conn.appIp,
            sport = conn.dport, dport = conn.sport,
            seq = 0, ack = conn.appNextSeq,
            flags = FLAG_RST or FLAG_ACK, payload = ByteArray(0)
        )
        writeOut(seg)
    }

    private fun tunnelClosed(conn: TcpConn) {
        if (!conn.finSentToApp) {
            conn.finSentToApp = true
            conn.state = State.CLOSED
            val seg = buildTCP(
                srcIp = conn.dstIp, dstIp = conn.appIp,
                sport = conn.dport, dport = conn.sport,
                seq = conn.serverNextSeq, ack = conn.appNextSeq,
                flags = FLAG_FIN or FLAG_ACK, payload = ByteArray(0)
            )
            writeOut(seg)
        }
        connTable.remove(conn.key)
    }

    private fun handleUdp(b: ByteArray, off: Int, len: Int, srcIp: Int, dstIp: Int) {
        if (len < 8) return
        val sport = readShortBE(b, off)
        val dport = readShortBE(b, off + 2)
        val payloadLen = (len - 8).coerceAtLeast(0)
        if (dport == 53 && payloadLen > 0 && off + 8 + payloadLen <= b.size) {
            val query = b.copyOfRange(off + 8, off + 8 + payloadLen)
            handleDnsQuery(srcIp, sport, dstIp, dport, query)
        }
    }

    private fun handleDnsQuery(appIp: Int, sport: Int, dnsIp: Int, dport: Int, query: ByteArray) {
        executor.execute {
            var tunnelRef: VlessTunnel? = null
            val dnsRespBuf = ByteArrayOutputStream()
            val tunnel = VlessTunnel(
                config,
                dnsServer,
                53,
                onData = { data ->
                    synchronized(dnsRespBuf) {
                        dnsRespBuf.write(data)
                        val all = dnsRespBuf.toByteArray()
                        if (all.size >= 2) {
                            val expectedLen = ((all[0].toInt() and 0xff) shl 8) or (all[1].toInt() and 0xff)
                            if (all.size >= 2 + expectedLen) {
                                val dnsPayload = all.copyOfRange(2, 2 + expectedLen)
                                val resp = buildUDP(dnsIp, appIp, dport, sport, dnsPayload)
                                writeOut(resp)
                                tunnelRef?.close()
                            }
                        }
                    }
                },
                onClose = {}
            )
            tunnelRef = tunnel
            if (tunnel.connect()) {
                val framed = ByteArray(2 + query.size)
                framed[0] = ((query.size ushr 8) and 0xff).toByte()
                framed[1] = (query.size and 0xff).toByte()
                System.arraycopy(query, 0, framed, 2, query.size)
                tunnel.send(framed)
            } else {
                tunnel.close()
            }
        }
    }

    private fun buildIPv4(src: Int, dst: Int, proto: Int, payload: ByteArray): ByteArray {
        val hlen = 20
        val tlen = hlen + payload.size
        val out = ByteArray(tlen)
        out[0] = 0x45
        out[1] = 0
        writeShortBE(out, 2, tlen)
        out[4] = 0
        out[5] = 0
        writeShortBE(out, 6, (packetId++ and 0xffff))
        out[8] = 64
        out[9] = proto.toByte()
        out[10] = 0
        out[11] = 0
        writeIntBE(out, 12, src)
        writeIntBE(out, 16, dst)
        writeShortBE(out, 10, checksum(out, 0, hlen))
        System.arraycopy(payload, 0, out, hlen, payload.size)
        return out
    }

    private fun buildTCP(
        srcIp: Int, dstIp: Int, sport: Int, dport: Int,
        seq: Long, ack: Long, flags: Int, payload: ByteArray
    ): ByteArray {
        val hlen = 20
        val tlen = hlen + payload.size
        val tcp = ByteArray(tlen)
        writeShortBE(tcp, 0, sport)
        writeShortBE(tcp, 2, dport)
        writeIntBE(tcp, 4, (seq and 0xffffffffL).toInt())
        writeIntBE(tcp, 8, (ack and 0xffffffffL).toInt())
        tcp[12] = (((hlen / 4) and 0x0f) shl 4).toByte()
        tcp[13] = flags.toByte()
        writeShortBE(tcp, 14, 65535)
        tcp[16] = 0
        tcp[17] = 0
        tcp[18] = 0
        tcp[19] = 0
        if (payload.isNotEmpty()) {
            System.arraycopy(payload, 0, tcp, hlen, payload.size)
        }
        val ck = tcpChecksum(srcIp, dstIp, tcp)
        tcp[16] = (ck ushr 8).toByte()
        tcp[17] = ck.toByte()
        return buildIPv4(srcIp, dstIp, 6, tcp)
    }

    private fun buildUDP(srcIp: Int, dstIp: Int, sport: Int, dport: Int, payload: ByteArray): ByteArray {
        val hlen = 8
        val udp = ByteArray(hlen + payload.size)
        writeShortBE(udp, 0, sport)
        writeShortBE(udp, 2, dport)
        writeShortBE(udp, 4, (hlen + payload.size))
        udp[6] = 0
        udp[7] = 0
        System.arraycopy(payload, 0, udp, hlen, payload.size)
        return buildIPv4(srcIp, dstIp, 17, udp)
    }

    private fun tcpChecksum(srcIp: Int, dstIp: Int, tcp: ByteArray): Int {
        val buf = ByteArray(12 + tcp.size)
        writeIntBE(buf, 0, srcIp)
        writeIntBE(buf, 4, dstIp)
        buf[8] = 0
        buf[9] = 0
        buf[10] = 6
        buf[11] = 0
        writeShortBE(buf, 12, tcp.size)
        System.arraycopy(tcp, 0, buf, 12, tcp.size)
        return checksum(buf, 0, buf.size)
    }

    private fun checksum(data: ByteArray, offset: Int, length: Int): Int {
        var sum = 0L
        var i = offset
        while (i < offset + length - 1) {
            sum += ((data[i].toInt() and 0xff) shl 8) or (data[i + 1].toInt() and 0xff)
            i += 2
        }
        if (length % 2 == 1) sum += (data[offset + length - 1].toInt() and 0xff) shl 8
        while ((sum ushr 16) != 0L) sum = (sum and 0xffffL) + (sum ushr 16)
        return (sum.inv() and 0xffffL).toInt()
    }

    private fun writeOut(packet: ByteArray) {
        synchronized(outLock) {
            try {
                output.write(packet)
                output.flush()
            } catch (_: Exception) {}
        }
    }

    private fun ipToString(ip: Int): String =
        "${(ip ushr 24) and 0xff}.${(ip ushr 16) and 0xff}.${(ip ushr 8) and 0xff}.${ip and 0xff}"

    private fun readIntBE(b: ByteArray, o: Int): Int =
        ((b[o].toInt() and 0xff) shl 24) or ((b[o + 1].toInt() and 0xff) shl 16) or
            ((b[o + 2].toInt() and 0xff) shl 8) or (b[o + 3].toInt() and 0xff)

    private fun readUInt32BE(b: ByteArray, o: Int): Long =
        readIntBE(b, o).toLong() and 0xffffffffL

    private fun readShortBE(b: ByteArray, o: Int): Int =
        ((b[o].toInt() and 0xff) shl 8) or (b[o + 1].toInt() and 0xff)

    private fun writeIntBE(b: ByteArray, o: Int, v: Int) {
        b[o] = (v ushr 24).toByte()
        b[o + 1] = (v ushr 16).toByte()
        b[o + 2] = (v ushr 8).toByte()
        b[o + 3] = v.toByte()
    }

    private fun writeShortBE(b: ByteArray, o: Int, v: Int) {
        b[o] = (v ushr 8).toByte()
        b[o + 1] = v.toByte()
    }

    private inner class TcpConn(
        val key: String,
        val appIp: Int,
        val sport: Int,
        val dstIp: Int,
        val dport: Int,
        var appSeq: Long
    ) {
        val isn = Random.nextLong(1, 0x7fffffffL)
        var appNextSeq = (appSeq + 1) and 0xffffffffL
        var serverNextSeq = (isn + 1) and 0xffffffffL
        var state = State.SYN_RECEIVED
        @Volatile
        var tunnel: VlessTunnel? = null
        var finSentToApp = false
        val pendingOut = ByteArrayOutputStream()

        fun dstIpStr() = ipToString(dstIp)

        fun handleSegment(flags: Int, seq: Long, payload: ByteArray) {
            if ((flags and FLAG_RST) != 0) {
                close()
                connTable.remove(key)
                return
            }
            when (state) {
                State.SYN_RECEIVED -> {
                    if ((flags and FLAG_ACK) != 0 && (flags and FLAG_SYN) == 0) {
                        state = State.ESTABLISHED
                        flushPending()
                    }
                }
                State.ESTABLISHED -> {
                    if (payload.isNotEmpty()) {
                        appNextSeq = (seq + payload.size) and 0xffffffffL
                        sendAck(this)
                        val t = tunnel
                        if (t != null) {
                            t.send(payload)
                        } else {
                            synchronized(pendingOut) { pendingOut.write(payload) }
                        }
                    }
                    if ((flags and FLAG_FIN) != 0) {
                        appNextSeq = (appNextSeq + 1) and 0xffffffffL
                        sendFin(this)
                    }
                }
                State.FIN_WAIT -> {}
                State.CLOSED -> {}
            }
        }

        fun flushPending() {
            val t = this.tunnel ?: return
            synchronized(pendingOut) {
                if (pendingOut.size() > 0) {
                    t.send(pendingOut.toByteArray())
                    pendingOut.reset()
                }
            }
        }

        fun close() {
            tunnel?.close()
        }
    }

    companion object {
        private const val FLAG_FIN = 0x01
        private const val FLAG_SYN = 0x02
        private const val FLAG_RST = 0x04
        private const val FLAG_PSH = 0x08
        private const val FLAG_ACK = 0x10
    }
}
